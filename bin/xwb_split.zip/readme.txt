Splits multi-XWBs to single XWBs for easier vgmstream consumption.

A valid .xsb file must be provided to extract the original filenames.
It must be named same as the .xwb, or specified with -x (infile).xsb.
As the name list in the .xsb is not always in the order of the .xwb data,
it can be hard to match otherwise.

If the .xsb contains names from multiple .xwb and autodetection fails,
use -w N to select which .xwb (1=first).

The -i option can be used to ignore the .xsb and attempt to extract filenames
from the .xwb instead (rarely found, though), or -I to just ignore any names.


xwb_split XSB issues (can be ignored with -i):
- not all XSB are parsed ok
- in rare cases the name order is not ok (Ikaruga, Mushihimesama SYS_SE).
  Since xwb_split usually works with unordered names, it may be a problem in the .xsb itself.
- XACT1 XSB (XBOX) barely tested
- XSB with different number of sounds vs XWB streams don't work yet


***

xwb splitter 1.0 Feb 27 2017

Usage: xwb_split.exe [options] (infile).xwb
Options:
    -x file.xsb: name of the .xsb companion file used for filenames
       Defaults to (infile).xwb if not specified)
    -w N: use wavebank N (1=first) in a multi .xsb
       Some .xsb have data for multiple .xwb, and autodetection may not work
    -i: ignore .xsb file and filenames
       Will try to use filename inside the .xwb, if found
    -I: ignore .xsb and .xwb filenames
    -m: multi only, don't parse .xwb with a single stream
       Otherwise it creates a .xwb with extracted filename
    -l: list only, don't create files
    -p: don't prefix names and use only extracted filename
       Defaults to infile_NNN__extracted-filename.xwb)
    -o: overwrite extracted files
