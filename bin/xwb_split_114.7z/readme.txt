XSB_SPLIT
---------

Splits multi-XWBs to single XWBs for easier vgmstream consumption.

A valid .xsb file must be provided to extract the original filenames.
It must be named like the .xwb, or specified with -x (infile).xsb.
As the name list in the .xsb is not always in the order of the .xwb data
it can be hard to match otherwise.

By default the names are prefixed as the name order is not always correct (but
almost always ok) and should be manually checked. Use -p to remove the prefix.

The -i option can be used to ignore the .xsb and attempt to extract filenames
from the .xwb instead (rarely found, though), or -I to just ignore any names.

Sometimes xwb_split can't extract names on its own and will ask for extra
flags (see below).

Known XSB issues (can be ignored with -i):
- not all XSB may be parsed ok
- XACT1 XSB (XBOX) barely tested

***

xwb splitter 1.1.4 May  27 2018

Usage: xwb_split [options] (infile).xwb
Options:
    -x file.xsb: name of the .xsb companion file used for stream names
       Defaults to (infile).xwb if not specified
    -w N: use wavebank N (1=first) in a multi .xsb
       Some .xsb have data for multiple .xwb, and autodetection may fail
       Selecting the wrong wavebank WILL extract wrong names
    -s N: start from sound N (1=first)
       Some .xsb have more sound data that .xwb streams exist.
       For those must specify the first sound to properly extract the name
    -c: ignore when there are more XSB sounds cues than regular sounds
    -n: ignore names not found
    -i: ignore .xsb file and names
       Will try to use stream name inside the .xwb, if found
    -I: ignore .xsb and .xwb names
    -m: multi only, don't parse .xwb with a single stream
       Otherwise it creates a .xwb with extracted names
    -p: don't prefix names and use extracted names only
       Defaults to infile_NNN__extracted-name.xwb)
    -P: prefix number only (NNN__extracted-name.xwb)
    -l: list only, don't create any files
    -o: overwrite extracted files
    -d: print debug info
    -a: alt extraction method if current fails
